document.addEventListener('DOMContentLoaded', ()=>{
  document.getElementById('year').textContent = new Date().getFullYear();

  const form = document.getElementById('contactForm');
  const status = document.getElementById('formStatus');

  form.addEventListener('submit', e=>{
    e.preventDefault();
    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const msg = form.message.value.trim();

    if(!name || !email || !msg) {
      status.textContent = "Please fill out all fields.";
      status.style.color = "red";
      return;
    }

    status.textContent = "Thank you for contacting Furrapy! We’ll get back to you soon.";
    status.style.color = "green";
    form.reset();
  });
});
